from django.shortcuts import render,HttpResponseRedirect
from .forms import WfmtJobsRegister
from .models import WfmtJobs
# Create your views here.
def addshow_view(request):
    if request.method=="GET":
        form=WfmtJobsRegister()
        HttpResponseRedirect("")
    if request.method=="POST":
        form=WfmtJobsRegister(request.POST)
        if form.is_valid():
            cp=form.cleaned_data["cp_number"]
            jd=form.cleaned_data["job_description"]
            est=form.cleaned_data["estimate_number"]
            sne=form.cleaned_data["sne_id"]
            sch=form.cleaned_data["scheme"]
            task=WfmtJobs(cp_number=cp,job_description=jd,estimate_number=est,sne_id=sne,scheme=sch)
            task.save()
            form=WfmtJobsRegister()
    jobs=WfmtJobs.objects.all()
    return render(request,"wfmtcrudApp/showoradd.html",{"form":form,"jobs":jobs})

#this id the code for the Delete request
def delete_view(request,id):
    job=WfmtJobs.objects.get(pk=id)
    job.delete()
    return addshow_view(request)
def update_view(request,id):
    task=WfmtJobs.objects.get(pk=id)
    form=WfmtJobsRegister(instance=task)
    if request.method=="POST":
        task=WfmtJobs.objects.get(pk=id)
        form=WfmtJobsRegister(request.POST,instance=task)
        form.save()
    return render(request, "wfmtcrudApp/update.html",{"id":id,"form":form})
