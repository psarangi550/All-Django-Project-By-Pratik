from wfmtcrudApp import views #importing the view function
from django.urls import path,include
urlpatterns = [
    path("", views.addshow_view, name="home"),
    path("<int:id>/",views.delete_view,name="deletedata"),
    path("index/<int:id>/",views.update_view,name="updatedata"),
]
