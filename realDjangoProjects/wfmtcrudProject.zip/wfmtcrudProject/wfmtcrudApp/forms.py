from django import forms #importing the forms from django module
from .models import WfmtJobs #importing the models class
class WfmtJobsRegister(forms.ModelForm):
    class Meta:
        model=WfmtJobs
        fields="__all__"
        widgets={
                "job_description":forms.Textarea(attrs={"class":"form-control","rows":"3","cols":"3","placeholder":"Enter Job details"}),
                "cp_number":forms.TextInput(attrs={"class":"form-control","placeholder":"Enter CP Number"}),
                "estimate_number":forms.TextInput({"class":"form-control","placeholder":" Enter Estimate Number"}),
                "sne_id":forms.NumberInput({"class":"form-control","placeholder":"Enter SNE ID"}),
                "scheme":forms.NumberInput({"class":"form-control","placeholder":"Enter Scheme No"}),
                }
