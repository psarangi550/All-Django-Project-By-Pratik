from django.contrib import admin
from . import models
# Register your models here.
@admin.register(models.WfmtJobs)
class WfmtJobsAdmin(admin.ModelAdmin):
    list_display=["cp_number","job_description","estimate_number","sne_id","scheme"]
