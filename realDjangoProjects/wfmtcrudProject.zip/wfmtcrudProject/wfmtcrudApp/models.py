from django.db import models

# Create your models here.
class WfmtJobs(models.Model):
    cp_number=models.CharField(max_length=20)
    job_description=models.CharField(max_length=500)
    estimate_number=models.CharField(max_length=20)
    sne_id=models.IntegerField()
    scheme=models.IntegerField()
